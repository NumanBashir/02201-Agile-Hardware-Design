# Lab 4 homework: CSR Adapter Generator

## Run the submission

Install Java and sbt. The build pins sbt 2.0.8, Scala 2.13.16, Chisel 6.7.0,
ChiselTest 6.0.0, and Apache POI 3.17. Internet access is needed to download
uncached dependencies on the first run.

After extracting, open a terminal in the `lab4` directory and run:

```sh
sbt "testOnly *"
```

Expected result: five successful Chisel tests, no canceled tests. Verilator,
Python, and Excel are not needed to run these tests. The Scala code reads the
included spreadsheets using Apache POI. `testOnly *` explicitly reruns all
suites with this sbt version.

Generate SystemVerilog with:

```sh
sbt "runMain CsrAdapter"
```

Output: `generated/CsrAdapter.sv`. The generator accepts an optional spreadsheet
path, for example `sbt "runMain CsrAdapter src/test/resources/tiny.xlsx"`.

## Contents and scope

- `src/main/scala/CsrAdapter.scala`: spreadsheet description parsing, dynamic
  hardware interfaces, APB access logic, registers and trigger signals.
- `src/main/scala/help/`: course-provided helpers; Sheet was updated to close files.
- `src/test/scala/`: five Chisel tests and the provided APB bus functional model.
- `soc.xlsx`: original course specification.
- `src/test/resources/tiny.xlsx`: additional configuration testing nonzero bit
  offsets, write-only access, initial values and different addresses.
- `README.md` and `doc/`: original lab instructions and solution documentation.
- Python generator and requirements: original reference only, not needed to test.

The design supports rw, ro, wotrg, rotrg and const fields. See README.md for
APB timing, initialization semantics and validation details. The optional
Python/SystemVerilog blackbox test is excluded as allowed by the assignment.
No FPGA synthesis or programming is claimed.

## AI/LLM usage

OpenAI Codex was used to generate the Chisel/Scala implementation, additional
tests and test spreadsheet, documentation, and this submission package, and to
run the tests and SystemVerilog generation. The provided course starter code,
Python reference generator, and lab specification were used as references.
