import org.scalatest.flatspec.AnyFlatSpec
import chiseltest._
import chisel3._

class GeneratorTest extends AnyFlatSpec with ChiselScalatestTester {

  val enableWaveform = true


  val annotations = if (enableWaveform) {
    Seq(WriteVcdAnnotation)
  } else {
    Seq()
  }

  "Chisel CSR Generator" should "generate CSR adapter for soc.xlsx" in {
    // Smoke test for the Chisel-generated adapter
    test(new CsrAdapter("soc.xlsx")).withAnnotations(annotations) { dut =>
      val bfm = new ApbMasterBfm(
        dut.clock,
        dut.reset,
        dut.apb.psel,
        dut.apb.penable,
        dut.apb.paddr,
        dut.apb.pwrite,
        dut.apb.pwdata,
        dut.apb.prdata,
        dut.apb.pready,
        dut.apb.pslverr
      )

      // reset DUT
      bfm.reset()

      bfm.readExpect(0x80000000L, Some(0xdeadbeefL)) // constant
    }
  }

}
